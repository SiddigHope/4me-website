const logo = '/images/logo_empty.png';
const app_mockup = '/images/app_mockup.png';
const mockup_right = '/images/mockup_right.png';
export default { 
    logo,
    app_mockup,
    mockup_right
 };
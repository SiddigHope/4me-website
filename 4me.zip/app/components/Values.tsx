import ValueSection from './value/ValueSection';

export default function Values() {
  return (
    <main className="min-h-screen">
      <ValueSection />
    </main>
  );
}
